# -*- coding: utf-8 -*-

APP_VERSION = "1.5"
